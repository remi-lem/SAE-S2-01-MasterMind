﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Modif_Options
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Modif_Options))
        Me.btn_quitter = New System.Windows.Forms.Button()
        Me.btn_modif_symb_1 = New System.Windows.Forms.Button()
        Me.btn_modif_symb_2 = New System.Windows.Forms.Button()
        Me.btn_modif_symb_3 = New System.Windows.Forms.Button()
        Me.btn_modif_symb_4 = New System.Windows.Forms.Button()
        Me.btn_modif_symb_5 = New System.Windows.Forms.Button()
        Me.lbl_modif_symb_def = New System.Windows.Forms.Label()
        Me.Btn_modif_temps = New System.Windows.Forms.Button()
        Me.lbl_symbole1 = New System.Windows.Forms.Label()
        Me.lbl_symbole2 = New System.Windows.Forms.Label()
        Me.lbl_symbole3 = New System.Windows.Forms.Label()
        Me.lbl_symbole4 = New System.Windows.Forms.Label()
        Me.lbl_symbole5 = New System.Windows.Forms.Label()
        Me.lbl_temps = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.nud_propositions = New System.Windows.Forms.NumericUpDown()
        Me.BtnColorPresent = New System.Windows.Forms.Button()
        Me.BtnColorPlace = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Pnl_Symboles = New System.Windows.Forms.Panel()
        Me.Pnl_Couleurs = New System.Windows.Forms.Panel()
        Me.Pnl_Inclassables = New System.Windows.Forms.Panel()
        Me.Btn_modif_chemin_fic_svg = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        CType(Me.nud_propositions, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_Symboles.SuspendLayout()
        Me.Pnl_Couleurs.SuspendLayout()
        Me.Pnl_Inclassables.SuspendLayout()
        Me.SuspendLayout()
        '
        'btn_quitter
        '
        Me.btn_quitter.Location = New System.Drawing.Point(536, 180)
        Me.btn_quitter.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn_quitter.Name = "btn_quitter"
        Me.btn_quitter.Size = New System.Drawing.Size(100, 30)
        Me.btn_quitter.TabIndex = 40
        Me.btn_quitter.Text = "Quitter"
        Me.btn_quitter.UseVisualStyleBackColor = True
        '
        'btn_modif_symb_1
        '
        Me.btn_modif_symb_1.Location = New System.Drawing.Point(136, 38)
        Me.btn_modif_symb_1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn_modif_symb_1.Name = "btn_modif_symb_1"
        Me.btn_modif_symb_1.Size = New System.Drawing.Size(99, 30)
        Me.btn_modif_symb_1.TabIndex = 11
        Me.btn_modif_symb_1.Text = "Modifier"
        Me.btn_modif_symb_1.UseVisualStyleBackColor = True
        '
        'btn_modif_symb_2
        '
        Me.btn_modif_symb_2.Location = New System.Drawing.Point(136, 73)
        Me.btn_modif_symb_2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn_modif_symb_2.Name = "btn_modif_symb_2"
        Me.btn_modif_symb_2.Size = New System.Drawing.Size(99, 30)
        Me.btn_modif_symb_2.TabIndex = 12
        Me.btn_modif_symb_2.Text = "Modifier"
        Me.btn_modif_symb_2.UseVisualStyleBackColor = True
        '
        'btn_modif_symb_3
        '
        Me.btn_modif_symb_3.Location = New System.Drawing.Point(136, 107)
        Me.btn_modif_symb_3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn_modif_symb_3.Name = "btn_modif_symb_3"
        Me.btn_modif_symb_3.Size = New System.Drawing.Size(99, 30)
        Me.btn_modif_symb_3.TabIndex = 13
        Me.btn_modif_symb_3.Text = "Modifier"
        Me.btn_modif_symb_3.UseVisualStyleBackColor = True
        '
        'btn_modif_symb_4
        '
        Me.btn_modif_symb_4.Location = New System.Drawing.Point(136, 142)
        Me.btn_modif_symb_4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn_modif_symb_4.Name = "btn_modif_symb_4"
        Me.btn_modif_symb_4.Size = New System.Drawing.Size(99, 30)
        Me.btn_modif_symb_4.TabIndex = 14
        Me.btn_modif_symb_4.Text = "Modifier"
        Me.btn_modif_symb_4.UseVisualStyleBackColor = True
        '
        'btn_modif_symb_5
        '
        Me.btn_modif_symb_5.Location = New System.Drawing.Point(136, 177)
        Me.btn_modif_symb_5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn_modif_symb_5.Name = "btn_modif_symb_5"
        Me.btn_modif_symb_5.Size = New System.Drawing.Size(99, 30)
        Me.btn_modif_symb_5.TabIndex = 15
        Me.btn_modif_symb_5.Text = "Modifier"
        Me.btn_modif_symb_5.UseVisualStyleBackColor = True
        '
        'lbl_modif_symb_def
        '
        Me.lbl_modif_symb_def.AutoSize = True
        Me.lbl_modif_symb_def.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_modif_symb_def.Location = New System.Drawing.Point(16, 16)
        Me.lbl_modif_symb_def.Name = "lbl_modif_symb_def"
        Me.lbl_modif_symb_def.Size = New System.Drawing.Size(77, 17)
        Me.lbl_modif_symb_def.TabIndex = 6
        Me.lbl_modif_symb_def.Text = "Symboles"
        '
        'Btn_modif_temps
        '
        Me.Btn_modif_temps.Location = New System.Drawing.Point(132, 37)
        Me.Btn_modif_temps.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Btn_modif_temps.Name = "Btn_modif_temps"
        Me.Btn_modif_temps.Size = New System.Drawing.Size(99, 30)
        Me.Btn_modif_temps.TabIndex = 21
        Me.Btn_modif_temps.Text = "Modifier"
        Me.Btn_modif_temps.UseVisualStyleBackColor = True
        '
        'lbl_symbole1
        '
        Me.lbl_symbole1.AutoSize = True
        Me.lbl_symbole1.Location = New System.Drawing.Point(16, 46)
        Me.lbl_symbole1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_symbole1.Name = "lbl_symbole1"
        Me.lbl_symbole1.Size = New System.Drawing.Size(88, 16)
        Me.lbl_symbole1.TabIndex = 9
        Me.lbl_symbole1.Text = "Symbole 1 : []"
        '
        'lbl_symbole2
        '
        Me.lbl_symbole2.AutoSize = True
        Me.lbl_symbole2.Location = New System.Drawing.Point(16, 80)
        Me.lbl_symbole2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_symbole2.Name = "lbl_symbole2"
        Me.lbl_symbole2.Size = New System.Drawing.Size(88, 16)
        Me.lbl_symbole2.TabIndex = 9
        Me.lbl_symbole2.Text = "Symbole 2 : []"
        '
        'lbl_symbole3
        '
        Me.lbl_symbole3.AutoSize = True
        Me.lbl_symbole3.Location = New System.Drawing.Point(17, 114)
        Me.lbl_symbole3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_symbole3.Name = "lbl_symbole3"
        Me.lbl_symbole3.Size = New System.Drawing.Size(88, 16)
        Me.lbl_symbole3.TabIndex = 9
        Me.lbl_symbole3.Text = "Symbole 3 : []"
        '
        'lbl_symbole4
        '
        Me.lbl_symbole4.AutoSize = True
        Me.lbl_symbole4.Location = New System.Drawing.Point(17, 149)
        Me.lbl_symbole4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_symbole4.Name = "lbl_symbole4"
        Me.lbl_symbole4.Size = New System.Drawing.Size(88, 16)
        Me.lbl_symbole4.TabIndex = 9
        Me.lbl_symbole4.Text = "Symbole 4 : []"
        '
        'lbl_symbole5
        '
        Me.lbl_symbole5.AutoSize = True
        Me.lbl_symbole5.Location = New System.Drawing.Point(17, 185)
        Me.lbl_symbole5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_symbole5.Name = "lbl_symbole5"
        Me.lbl_symbole5.Size = New System.Drawing.Size(88, 16)
        Me.lbl_symbole5.TabIndex = 9
        Me.lbl_symbole5.Text = "Symbole 5 : []"
        '
        'lbl_temps
        '
        Me.lbl_temps.AutoSize = True
        Me.lbl_temps.Location = New System.Drawing.Point(4, 46)
        Me.lbl_temps.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_temps.Name = "lbl_temps"
        Me.lbl_temps.Size = New System.Drawing.Size(83, 16)
        Me.lbl_temps.TabIndex = 10
        Me.lbl_temps.Text = "Temps : 1:30"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(5, 78)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 32)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Nombre de " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "propositions"
        '
        'nud_propositions
        '
        Me.nud_propositions.Location = New System.Drawing.Point(132, 84)
        Me.nud_propositions.Margin = New System.Windows.Forms.Padding(4)
        Me.nud_propositions.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nud_propositions.Name = "nud_propositions"
        Me.nud_propositions.Size = New System.Drawing.Size(99, 22)
        Me.nud_propositions.TabIndex = 22
        Me.nud_propositions.Value = New Decimal(New Integer() {15, 0, 0, 0})
        '
        'BtnColorPresent
        '
        Me.BtnColorPresent.Location = New System.Drawing.Point(8, 38)
        Me.BtnColorPresent.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnColorPresent.Name = "BtnColorPresent"
        Me.BtnColorPresent.Size = New System.Drawing.Size(100, 28)
        Me.BtnColorPresent.TabIndex = 31
        Me.BtnColorPresent.Text = "Présent"
        Me.BtnColorPresent.UseVisualStyleBackColor = True
        '
        'BtnColorPlace
        '
        Me.BtnColorPlace.Location = New System.Drawing.Point(8, 73)
        Me.BtnColorPlace.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnColorPlace.Name = "BtnColorPlace"
        Me.BtnColorPlace.Size = New System.Drawing.Size(100, 28)
        Me.BtnColorPlace.TabIndex = 32
        Me.BtnColorPlace.Text = "Bien placé"
        Me.BtnColorPlace.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(4, 16)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 17)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Couleurs"
        '
        'Pnl_Symboles
        '
        Me.Pnl_Symboles.Controls.Add(Me.lbl_modif_symb_def)
        Me.Pnl_Symboles.Controls.Add(Me.btn_modif_symb_1)
        Me.Pnl_Symboles.Controls.Add(Me.btn_modif_symb_2)
        Me.Pnl_Symboles.Controls.Add(Me.btn_modif_symb_3)
        Me.Pnl_Symboles.Controls.Add(Me.btn_modif_symb_4)
        Me.Pnl_Symboles.Controls.Add(Me.btn_modif_symb_5)
        Me.Pnl_Symboles.Controls.Add(Me.lbl_symbole1)
        Me.Pnl_Symboles.Controls.Add(Me.lbl_symbole2)
        Me.Pnl_Symboles.Controls.Add(Me.lbl_symbole5)
        Me.Pnl_Symboles.Controls.Add(Me.lbl_symbole3)
        Me.Pnl_Symboles.Controls.Add(Me.lbl_symbole4)
        Me.Pnl_Symboles.Location = New System.Drawing.Point(1, 2)
        Me.Pnl_Symboles.Margin = New System.Windows.Forms.Padding(4)
        Me.Pnl_Symboles.Name = "Pnl_Symboles"
        Me.Pnl_Symboles.Size = New System.Drawing.Size(259, 223)
        Me.Pnl_Symboles.TabIndex = 10
        '
        'Pnl_Couleurs
        '
        Me.Pnl_Couleurs.Controls.Add(Me.Label2)
        Me.Pnl_Couleurs.Controls.Add(Me.BtnColorPlace)
        Me.Pnl_Couleurs.Controls.Add(Me.BtnColorPresent)
        Me.Pnl_Couleurs.Location = New System.Drawing.Point(528, 2)
        Me.Pnl_Couleurs.Margin = New System.Windows.Forms.Padding(4)
        Me.Pnl_Couleurs.Name = "Pnl_Couleurs"
        Me.Pnl_Couleurs.Size = New System.Drawing.Size(121, 155)
        Me.Pnl_Couleurs.TabIndex = 30
        '
        'Pnl_Inclassables
        '
        Me.Pnl_Inclassables.Controls.Add(Me.Btn_modif_chemin_fic_svg)
        Me.Pnl_Inclassables.Controls.Add(Me.Label3)
        Me.Pnl_Inclassables.Controls.Add(Me.Label4)
        Me.Pnl_Inclassables.Controls.Add(Me.lbl_temps)
        Me.Pnl_Inclassables.Controls.Add(Me.Btn_modif_temps)
        Me.Pnl_Inclassables.Controls.Add(Me.nud_propositions)
        Me.Pnl_Inclassables.Controls.Add(Me.Label1)
        Me.Pnl_Inclassables.Location = New System.Drawing.Point(268, 2)
        Me.Pnl_Inclassables.Margin = New System.Windows.Forms.Padding(4)
        Me.Pnl_Inclassables.Name = "Pnl_Inclassables"
        Me.Pnl_Inclassables.Size = New System.Drawing.Size(252, 171)
        Me.Pnl_Inclassables.TabIndex = 20
        '
        'Btn_modif_chemin_fic_svg
        '
        Me.Btn_modif_chemin_fic_svg.Location = New System.Drawing.Point(132, 126)
        Me.Btn_modif_chemin_fic_svg.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Btn_modif_chemin_fic_svg.Name = "Btn_modif_chemin_fic_svg"
        Me.Btn_modif_chemin_fic_svg.Size = New System.Drawing.Size(99, 30)
        Me.Btn_modif_chemin_fic_svg.TabIndex = 23
        Me.Btn_modif_chemin_fic_svg.Text = "Modifier"
        Me.Btn_modif_chemin_fic_svg.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(4, 16)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(97, 17)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Inclassables"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 124)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(111, 32)
        Me.Label4.TabIndex = 20
        Me.Label4.Text = "Chemin du fichier " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "de sauvegarde"
        '
        'Form_Modif_Options
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(655, 230)
        Me.Controls.Add(Me.Pnl_Inclassables)
        Me.Controls.Add(Me.Pnl_Couleurs)
        Me.Controls.Add(Me.Pnl_Symboles)
        Me.Controls.Add(Me.btn_quitter)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Form_Modif_Options"
        Me.Text = "Modification des options"
        CType(Me.nud_propositions, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_Symboles.ResumeLayout(False)
        Me.Pnl_Symboles.PerformLayout()
        Me.Pnl_Couleurs.ResumeLayout(False)
        Me.Pnl_Couleurs.PerformLayout()
        Me.Pnl_Inclassables.ResumeLayout(False)
        Me.Pnl_Inclassables.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btn_quitter As Button
    Friend WithEvents btn_modif_symb_1 As Button
    Friend WithEvents btn_modif_symb_2 As Button
    Friend WithEvents btn_modif_symb_3 As Button
    Friend WithEvents btn_modif_symb_4 As Button
    Friend WithEvents btn_modif_symb_5 As Button
    Friend WithEvents lbl_modif_symb_def As Label
    Friend WithEvents Btn_modif_temps As Button
    Friend WithEvents lbl_symbole1 As Label
    Friend WithEvents lbl_symbole2 As Label
    Friend WithEvents lbl_symbole3 As Label
    Friend WithEvents lbl_symbole4 As Label
    Friend WithEvents lbl_symbole5 As Label
    Friend WithEvents lbl_temps As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents nud_propositions As NumericUpDown
    Friend WithEvents BtnColorPresent As Button
    Friend WithEvents BtnColorPlace As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Pnl_Symboles As Panel
    Friend WithEvents Pnl_Couleurs As Panel
    Friend WithEvents Pnl_Inclassables As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Btn_modif_chemin_fic_svg As Button
    Friend WithEvents Label4 As Label
End Class
